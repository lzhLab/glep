/*************************************************************************
    > File Name: calculatetfidf.h
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Friday, June 17, 2016 09:19:34
 ************************************************************************/
#ifndef _CALCULATETFIDF_H
#define _CALCULATETFIDF_H

#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <numeric>
#include <math.h>

using namespace std;

class Calculatetfidf{
private:
	map<string,float>* mat_map;
	vector<vector<string> >* vclusters;
	vector<vector<float> > tfidf;
public:
	~Calculatetfidf();
	Calculatetfidf(vector<vector<string> >* ,map<string,float>* );
	vector<vector<float> > updatefeaturevector();
	vector<float> getfeaturevector(vector<string>* );
};
#endif 