/*************************************************************************
    > File Name: main.cpp
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Wednesday, June 15, 2016 11:11:12
 ************************************************************************/

#include <iostream>
#include <algorithm>
#include "Eigen/Dense"
#include "stdlib.h"
#include "time.h"

#include "readnet.h"
#include "seedcluster.h"
#include "calculatefeaturevector.h"
#include "expandcluster.h"

using namespace std;

#define PACKAGE_NAME "Glep"
#define PACKAGE_BUGREPORT "wshg_gxu@163.com"
#define PACKAGE_VERSION "1.0.0"
#define AUTHOR "Wu Shaogui"

static float RANDOM_WALK_VALUE=0.035;
static int CLUSTER_DEGREE=1;
static float EXPAND_SIMILARITY=0.998;
static char* INPUT_FILE="";
static char* OUTPUT_FILE="";

static const char *USAGE_MESSAGE =
"Program: " PACKAGE_NAME "\n"
"Version: " PACKAGE_VERSION "\n"
"Contact: " AUTHOR " [" PACKAGE_BUGREPORT "]\n"
"Usage: " PACKAGE_NAME " [OPTION] inputpdb output\n"
"\n"
"    -v, --version                display this version and exit.\n"
"    -h, --help                   display this help and exit.\n"
"    -r, --random_walk[float]     The minimum value used to cut the weighted graph produced from random walk (default: 0.035).\n"
"    -d, --degree[number]         The maximum degree of scalability (default: 1).\n"
"    -e, --expand[float]          The minimum TF-IDF featured similarity used to expand seeds (default: 0.997).\n\n"
"\nReport bugs to " PACKAGE_BUGREPORT "\n\n";


static const char *Example_MESSAGE=
"Example:\n"
"./glep test.net test.clu\n"
"./glep -r 0.037 test.net test.clu\n"
"./glep -r 0.037 -d 2 test.net test.clu\n"
"./glep -r 0.037 -d 2 -e 0.998 test.net test.clu\n";

bool greater_equal_secon_two(const vector<string> &v1,const vector<string> &v2){
    return v1.size()>v2.size();
}

//Initialization parameters
void initparse(int argc,char *argv[]){
    switch(argc){
        case 1:{
            cout<<"You can use '" PACKAGE_NAME " -h' or '" PACKAGE_NAME " -help' to display help."<<endl;
            exit(0);
           }
        case 2:{
            if(strcmp(argv[1],"-h")==0 or strcmp(argv[1],"--help")==0 ){
                cout<<USAGE_MESSAGE;
                exit(0);
            }
            else if(strcmp(argv[1],"-v")==0 or strcmp(argv[1],"--version")==0 ){
                cout<<"Program: " PACKAGE_NAME "\nVersion: " PACKAGE_VERSION "\n";
                exit(0);
            }
            else{
                cout<<"You can use '" PACKAGE_NAME " -h' or '" PACKAGE_NAME " -help' to display help."<<endl;
                exit(0);                
            }
           }
        default:{
            if(argc==4 or argc==6 or argc==8 or argc>=10){
                cout<<"Wrong input,you can use './glep -h' for help or use the following commands." <<endl;
                cout<<Example_MESSAGE<<endl;
                exit(0);               
            }

            for(int i=1;i<argc-2;i=i+1){
                if(strcmp(argv[i],"-r")==0){
                    RANDOM_WALK_VALUE=atof(argv[i+1]);
                    i+=1;
                }
                else if(strcmp(argv[i],"-d")==0){
                    CLUSTER_DEGREE=atoi(argv[i+1]);
                    i+=1;
                }
                else if(strcmp(argv[i],"-e")==0){
                    EXPAND_SIMILARITY=atof(argv[i+1]);
                    i+=1;
                }
            }

            if(strcmp(argv[argc-2],"-")==0){
                cout<<"Input file error"<<endl;
            }else{
                INPUT_FILE=argv[argc-2];
            }

            if(strcmp(argv[argc-1],"-")==0){
                cout<<"Output file error"<<endl;
            }else{
                OUTPUT_FILE=argv[argc-1];
            }
        }
    }
}

//Storage clustering results
void storeculster(std::vector<std::vector<string> > vclusters,char* outputfilepath){
    ofstream outfile;
    outfile.open(outputfilepath);
    for(int i=0;i<vclusters.size();i++){
        for(int j=0;j<vclusters.at(i).size();j++){
            outfile<<vclusters[i][j]<<" ";
        }
        outfile<<""<<endl;
    }
    outfile.close();
}

int main(int argc,char *argv[]){

    // All points
    std::vector<string> rowcolname;
    // All connections
    std::map<string,float> mat_map;
    // Clustering results
    std::vector<vector<string> > vclusters;

    // Judgment and initialization parameters
    initparse(argc,argv);
    
    // Read file
    ReadNet readnet(INPUT_FILE);
    readnet.readOriginGraph(&rowcolname,&mat_map);
    
    cout<<"read done.....points size:"<<rowcolname.size()<<"  Number of edges:"<<mat_map.size()<<endl;

    // First clustering
    GetSeedCluster getseed(rowcolname.size());
    MatrixXf mat_w=getseed.getMatrix(&rowcolname,&mat_map);
    MatrixXf pi=getseed.getpi(&mat_w);
    vclusters=getseed.getseed(RANDOM_WALK_VALUE,pi,rowcolname);
    sort(vclusters.begin(),vclusters.end(),greater_equal_secon_two);
    getseed.seeduniq(&vclusters);
    
    cout<<"Seed cluster done....."<<endl;

    
    cout<<"Start expanding.......  degree:"<<CLUSTER_DEGREE<<"  Expand similarity:"<<EXPAND_SIMILARITY<<endl;
    //Extend seedcluster
    Finalcluster finalcluster(&vclusters,&mat_map,&rowcolname,CLUSTER_DEGREE,EXPAND_SIMILARITY);
    finalcluster.GlobalProcess();

    cout<<"Expand done,results written in "<<OUTPUT_FILE<<endl;
    // Storage clustering results
    storeculster(vclusters,OUTPUT_FILE);

    return 0;
}
