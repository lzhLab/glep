/*************************************************************************
    > File Name: seedcluster.h
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Thursday, June 16, 2016 22:15:16
 ************************************************************************/


#ifndef _GETSEEDCLUSTER_H
#define _GETSEEDCLUSTER_H
#include <iostream>
#include "Eigen/Dense"
#include <vector>
#include <map>
#include <algorithm>

using namespace std;
using namespace Eigen;

class GetSeedCluster{
    private:
        int rowcollen;
    public:
        GetSeedCluster(int);
        ~GetSeedCluster();
        MatrixXf getMatrix(vector<string> *rowcolname,map<string,float> *mat_map);
        MatrixXf getpi(MatrixXf*);
        vector<vector<string> > getseed(float,MatrixXf,vector<string>);
        void seeduniq(vector<vector<string> >*);
        void cleardata(vector<vector<string> >* vclusters);
};
#endif
