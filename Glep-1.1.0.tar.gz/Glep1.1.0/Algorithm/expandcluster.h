/*************************************************************************
    > File Name: expandcluster.h
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Saturday, June 18, 2016 12:43:12
 ************************************************************************/
#ifndef _FINALCLUSTER_H
#define _FINALCLUSTER_H
#include "calculatetfidf.h"
#include <assert.h>
#include <math.h>

using namespace std;

class Finalcluster{
private:
    vector<vector<string> >* vclusters;
    map<string,float>* mat_map;
    vector<string>* allnodes;
    int degree;
    float similarity;
public:
    ~Finalcluster();
    Finalcluster(vector<vector<string> >*,map<string,float>*,vector<string>*,int,float); 	
    void GlobalProcess();
    float ComputeCos(vector<float> A,vector<float> B);
    float norm(vector<float> A);
    float InnerProduct(vector<float> A,vector<float> B);
    void  gofowared(vector<vector<string> >* vclusters,int index);
    vector<string> getAlllastNodesClusters(vector<string> vclusters);
    bool check(vector<string> ,string);
};

#endif