/*************************************************************************
    > File Name: calculatefeaturevector.h
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Thursday, June 16, 2016 23:05:55
 ************************************************************************/

#ifndef _CALCULATEFEATUREVECTOR_H
#define _CALCULATEFEATUREVECTOR_H
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <numeric>
#include <math.h>
#include "Eigen/Dense"

using namespace std;
using namespace Eigen;

class CalculateFeatureVector{
    private:
        vector<string>* vcluster;
        map<string,float>* mat_map;
    public:
    CalculateFeatureVector(vector<string>*,map<string,float>*);
    ~CalculateFeatureVector();
    float subdensity();
    vector<float> degree();
    vector<float> degreecorrelation();
    vector<float> clustercoefficient();
    vector<float> topologicalcoefficient();
    vector<float> eigenvalues();
    vector<float> mergetovector();
    vector<float> mergetovectororder();
    void print();
};
#endif
