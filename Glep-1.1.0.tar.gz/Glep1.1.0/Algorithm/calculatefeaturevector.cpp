/*************************************************************************
    > File Name: calculatefeaturevector.cpp
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Thursday, June 16, 2016 23:13:22
 ************************************************************************/

#include<iostream>
#include "calculatefeaturevector.h"

using namespace std;

CalculateFeatureVector::CalculateFeatureVector(vector<string>* vcluster1,map<string,float>* mat_map1){
    vcluster=vcluster1;
    mat_map=mat_map1;
}

CalculateFeatureVector::~CalculateFeatureVector(){

}

float CalculateFeatureVector::subdensity(){      
    int vnumber=0;
    for(vector<string>::iterator iti=vcluster->begin();iti!=vcluster->end()-1;iti++){
        for(vector<string>::iterator itj=iti+1;itj!=vcluster->end();itj++){
            string finds_1='-'+*iti+'-'+*itj;
            string finds_2='-'+*itj+'-'+*iti;
            map<string,float>::iterator itfinds_1=mat_map->find(finds_1);
            map<string,float>::iterator itfinds_2=mat_map->find(finds_2);
            if(itfinds_1!=mat_map->end()){
                vnumber+=1;   
            }
            if(itfinds_2!=mat_map->end()){
                vnumber+=1;   
            }
        }
    }
    float subden=0.0;
    int numv=vcluster->size();
    if(vnumber==0){
        subden=0.0;
    }
    else{
        subden=2*vnumber*1.0/(numv*(numv-1))*1.0;
    }
    return subden;
}

vector<float> CalculateFeatureVector::degree(){
    vector<float> subdegree;
    for(vector<string>::iterator iti=vcluster->begin();iti!=vcluster->end();iti++){
        float everynodedegree=0.0;
        for(vector<string>::iterator itj=vcluster->begin();itj!=vcluster->end();itj++){
            if(iti!=itj){
                string search1='-'+*iti+'-'+*itj;
                string search2='-'+*itj+'-'+*iti;
                map<string,float>::iterator itfinds_1=mat_map->find(search1);
                map<string,float>::iterator itfinds_2=mat_map->find(search2);
                if(itfinds_1!=mat_map->end()){
                    everynodedegree+=1.0;   
                }
                if(itfinds_2!=mat_map->end()){
                    everynodedegree+=1.0;
                }
            }
        }
        subdegree.push_back(everynodedegree);
    }
    float maxdegree=*max_element(subdegree.begin(),subdegree.end());
    float sum=accumulate(subdegree.begin(),subdegree.end(),0.0);
    float meandegree=sum/subdegree.size()*1.0;
    sort(subdegree.begin(),subdegree.end());
    float mediandegree=0.0;
    if(subdegree.size()==1){
        mediandegree=subdegree[0];
    }
    else{
        if(subdegree.size()%2==1){
            mediandegree=subdegree[(subdegree.size()+1)/2]*1.0;
        }
        else{
            mediandegree=(subdegree[subdegree.size()/2]+subdegree[subdegree.size()/2-1])*1.0/2.0;
        }
    }
    float accum=0.0;
    for(vector<float>::iterator it=subdegree.begin();it!=subdegree.end();it++){
        accum+=(*it-meandegree)*(*it-meandegree);
    }
    float vardegree=0.0;
    if(subdegree.size()==1){
        vardegree=0.0;
    }
    else{
        vardegree=sqrt(accum/(subdegree.size()-1));
    }
    subdegree.clear();
    vector<float> temp;
    temp.push_back(meandegree);
    temp.push_back(vardegree);
    temp.push_back(mediandegree);
    temp.push_back(maxdegree);
    return temp;
}

vector<float> CalculateFeatureVector::degreecorrelation(){
    vector<vector<int> > nodesneighbers;
    vector<int> tempdegrees;
    for(int ti=0;ti<vcluster->size();ti++){
        int nodedegree=0;
        vector<int> nodeneighbernodeslocation;
        for(int tj=0;tj<vcluster->size();tj++){
            if(ti!=tj){
                string search1='-'+vcluster->at(ti)+'-'+vcluster->at(tj);
                string search2='-'+vcluster->at(tj)+'-'+vcluster->at(ti);
                map<string,float>::iterator finds_1=mat_map->find(search1);
                map<string,float>::iterator finds_2=mat_map->find(search2);
                if(finds_1!=mat_map->end()){
                    nodedegree+=1;
                    nodeneighbernodeslocation.push_back(tj);
                }
                if(finds_2!=mat_map->end()){
                    nodedegree+=1;
                    nodeneighbernodeslocation.push_back(tj);
                }
            }
        }
        tempdegrees.push_back(nodedegree);
        nodesneighbers.push_back(nodeneighbernodeslocation);
        nodeneighbernodeslocation.clear();
    }
    vector<float> degreecorrelationKNN;
    for(int ni=0;ni<nodesneighbers.size();ni++){
        int sumknn=0;
        for(int nj=0;nj<nodesneighbers[ni].size();nj++){
            int cnt=nodesneighbers[ni][nj];
            sumknn+=tempdegrees[cnt];
        }
        float degreecorrelation=0.0;
        if(sumknn==0){
            degreecorrelation=0.0;
        }
        else{
            degreecorrelation=sumknn*1.0/nodesneighbers[ni].size();
        }
        degreecorrelationKNN.push_back(degreecorrelation);
    }
    tempdegrees.clear();
    nodesneighbers.clear();
    float maxdegreecorrelation=*max_element(degreecorrelationKNN.begin(),degreecorrelationKNN.end());
    float sum=accumulate(degreecorrelationKNN.begin(),degreecorrelationKNN.end(),0.0);
    float meandegreecorrelation=sum/degreecorrelationKNN.size()*1.0;
    float accum=0.0;
    for(vector<float>::iterator it=degreecorrelationKNN.begin();it!=degreecorrelationKNN.end();it++){
        accum+=(*it-meandegreecorrelation)*(*it-meandegreecorrelation);
    }
    float vardegreecorrelation=0.0;
    if(degreecorrelationKNN.size()==1){
        vardegreecorrelation=0.0;
    }
    else{
        vardegreecorrelation=sqrt(accum/(degreecorrelationKNN.size()-1));
    }
    degreecorrelationKNN.clear();
    vector<float> temp;
    temp.push_back(meandegreecorrelation);
    temp.push_back(vardegreecorrelation);
    temp.push_back(maxdegreecorrelation);
    return temp;
}

vector<float> CalculateFeatureVector::clustercoefficient(){
    vector<vector<string> > nodesneighbersstring;
    for(int ti=0;ti<vcluster->size();ti++){
        vector<string> singlenodeneighbers; 
        for(int tj=0;tj<vcluster->size();tj++){
            if(tj!=ti){
                string search1='-'+vcluster->at(ti)+'-'+vcluster->at(tj);
                string search2='-'+vcluster->at(tj)+'-'+vcluster->at(ti);
                map<string,float>::iterator finds_1=mat_map->find(search1);
                map<string,float>::iterator finds_2=mat_map->find(search2);
                if(finds_1!=mat_map->end()){
                    singlenodeneighbers.push_back(vcluster->at(tj));
                }
                if(finds_2!=mat_map->end()){
                    singlenodeneighbers.push_back(vcluster->at(tj));
                }
            }
        }
        nodesneighbersstring.push_back(singlenodeneighbers);
        singlenodeneighbers.clear();
    }
    vector<float> ccn;
    for(int cpi=0;cpi<nodesneighbersstring.size();cpi++){
        int edgesum=0;
        for(int cpti=0;cpti<nodesneighbersstring[cpi].size();cpti++){
            for(int cptj=0;cptj<nodesneighbersstring[cpi].size();cptj++){
                if(cpti!=cptj){
                    string search3='-'+nodesneighbersstring[cpi][cpti]+'-'+nodesneighbersstring[cpi][cptj];
                    string search4='-'+nodesneighbersstring[cpi][cptj]+'-'+nodesneighbersstring[cpi][cpti];
                    map<string,float>::iterator finds_3=mat_map->find(search3);
                    map<string,float>::iterator finds_4=mat_map->find(search4);
                    if(finds_3!=mat_map->end()){
                        edgesum+=1;
                    }
                    if(finds_4!=mat_map->end()){
                        edgesum+=1;
                    }
                }
            }
        }
        float clustercoefficientnumber=0.0;
        int lensnn=nodesneighbersstring[cpi].size();
        if(lensnn==0||lensnn==1){
            clustercoefficientnumber=0.0;
        }
        else{
            clustercoefficientnumber=2*edgesum*1.0/(lensnn*(lensnn-1));
        }
        ccn.push_back(clustercoefficientnumber);
    }
    nodesneighbersstring.clear();
    float maxclustercoefficientnumber=*max_element(ccn.begin(),ccn.end());
    float sum=accumulate(ccn.begin(),ccn.end(),0.0);
    float meanclustercoefficientnumber=sum/ccn.size()*1.0;
    float accum=0.0;
    for(vector<float>::iterator it=ccn.begin();it!=ccn.end();it++){
        accum+=(*it-meanclustercoefficientnumber)*(*it-meanclustercoefficientnumber);
    }
    float varclustercoefficientnumber=0.0;
    if(ccn.size()==1){
        varclustercoefficientnumber=0.0;
    }
    else{
        varclustercoefficientnumber=sqrt(accum/(ccn.size()-1));
    }
    ccn.clear();
    vector<float> temp;
    temp.push_back(meanclustercoefficientnumber);
    temp.push_back(varclustercoefficientnumber);
    temp.push_back(maxclustercoefficientnumber);
    return temp;
}

vector<float> CalculateFeatureVector::topologicalcoefficient(){
    vector<float> tempsingledata;
    vector<vector<string> > nodesneighbers;
    for(int ti=0;ti<vcluster->size();ti++){
        vector<string> singlenodeneighbersinclude;
        singlenodeneighbersinclude.push_back(vcluster->at(ti));
        for(int tj=0;tj<vcluster->size();tj++){
            if(tj!=ti){
                string search1='-'+vcluster->at(ti)+'-'+vcluster->at(tj);
                string search2='-'+vcluster->at(tj)+'-'+vcluster->at(ti);
                map<string,float>::iterator finds_1=mat_map->find(search1);
                map<string,float>::iterator finds_2=mat_map->find(search2);
                if(finds_1!=mat_map->end()){
                    singlenodeneighbersinclude.push_back(vcluster->at(tj));   
                }
                if(finds_2!=mat_map->end()){
                    singlenodeneighbersinclude.push_back(vcluster->at(tj));
                }
            }
        }
        nodesneighbers.push_back(singlenodeneighbersinclude);
        singlenodeneighbersinclude.clear();
    }
    for(int tci=0;tci<nodesneighbers.size();tci++){
        int sumtc=0;
        int count=0;
        sort(nodesneighbers[tci].begin(),nodesneighbers[tci].end());
        for(int tcj=0;tcj<nodesneighbers.size();tcj++){
            if(tcj!=tci){
                sort(nodesneighbers[tcj].begin(),nodesneighbers[tcj].end());
                vector<string> simset;
                set_intersection(nodesneighbers[tci].begin(),nodesneighbers[tci].end(),nodesneighbers[tcj].begin(),nodesneighbers[tcj].end(),back_inserter(simset));
                int simlen=simset.size();
                if(simlen>=1){
                    sumtc+=simlen;
                    count+=1;
                    string search3=nodesneighbers[tcj][0];
                    string search4=nodesneighbers[tci][0];
                    vector<string>::iterator finds_3=find(nodesneighbers[tci].begin(),nodesneighbers[tci].end(),search3);
                    vector<string>::iterator finds_4=find(nodesneighbers[tci].begin(),nodesneighbers[tci].end(),search4);
                    if(finds_3!=nodesneighbers[tci].end()){
                        sumtc+=1;
                    }
                    if(finds_4!=nodesneighbers[tcj].end()){
                        sumtc+=1;
                    }
                }
                simset.clear();
            }
        }
        float topoco=0.0;
        if(sumtc==0){
            topoco=0.0;
        }else{
            float topocotemp=sumtc*1.0/count;
            topoco=topocotemp*1.0/(nodesneighbers[tci].size()-1);
        }
        tempsingledata.push_back(topoco);
    }
    nodesneighbers.clear();
    float maxtopoc=*max_element(tempsingledata.begin(),tempsingledata.end());
    float sum=accumulate(tempsingledata.begin(),tempsingledata.end(),0.0);
    float meantopoc=sum/tempsingledata.size()*1.0;
    float accum=0.0;
    for(vector<float>::iterator it=tempsingledata.begin();it!=tempsingledata.end();it++){
        accum+=(*it-meantopoc)*(*it-meantopoc);
    }
    float vartopoc=0.0;
    if(tempsingledata.size()==1){
        vartopoc=0.0;
    }
    else{
        vartopoc=sqrt(accum/(tempsingledata.size()-1));
    }
    tempsingledata.clear();
    vector<float> temp;
    temp.push_back(meantopoc);
    temp.push_back(vartopoc);
    temp.push_back(maxtopoc);
    return temp;
}

vector<float> CalculateFeatureVector::eigenvalues(){
    int rowcollen=vcluster->size();
    MatrixXf mattemp(rowcollen,rowcollen);
    for(int evi=0;evi<vcluster->size();evi++){
        for(int evj=0;evj<vcluster->size();evj++){
            if(evj!=evi){
                string search1='-'+vcluster->at(evi)+'-'+vcluster->at(evj);
                string search2='-'+vcluster->at(evj)+'-'+vcluster->at(evi);
                map<string,float>::iterator finds_1=mat_map->find(search1);
                map<string,float>::iterator finds_2=mat_map->find(search2);
                if(finds_1!=mat_map->end() || finds_2!=mat_map->end()){
                    mattemp(evi,evj)=1.0;   
                }else{
                    mattemp(evi,evj)=0.0;
                }
            }else{
                mattemp(evi,evj)=0.0;
            }
        }
    }
    JacobiSVD<MatrixXf> svd(mattemp,ComputeThinU|ComputeThinV);
    vector<float> tempdata;
    if(svd.singularValues().size()<3){
        int lensvd=svd.singularValues().size();
        for(int singulari=0;singulari<svd.singularValues().size();singulari++){
            tempdata.push_back(svd.singularValues()[singulari]);
        }
        for(int svdi=0;svdi<3-lensvd;svdi++){
            tempdata.push_back(0);
        }
    }else{
        for(int singulari=0;singulari<3;singulari++){
            tempdata.push_back(svd.singularValues()[singulari]);
        }
    }
    return tempdata;
}

vector<float> CalculateFeatureVector::mergetovector(){
    float subdensitydata=subdensity();

    vector<float> degreedata=degree();
    vector<float> degreecorrelationdata=degreecorrelation();

    vector<float> clustercoefficientdata=clustercoefficient();
    vector<float> topologicalcoefficientdata=topologicalcoefficient();
   
    vector<float> eigenvaluesdata=eigenvalues();
    vector<float> alldata;
    alldata.push_back(subdensitydata);
    for(int i_1=0;i_1<degreedata.size();i_1++){
        alldata.push_back(degreedata[i_1]);
    }
    for(int i_2=0;i_2<degreecorrelationdata.size();i_2++){
        alldata.push_back(degreecorrelationdata[i_2]);
    }
    for(int i_3=0;i_3<clustercoefficientdata.size();i_3++){
        alldata.push_back(clustercoefficientdata[i_3]);
    }
    for(int i_4=0;i_4<topologicalcoefficientdata.size();i_4++){
        alldata.push_back(topologicalcoefficientdata[i_4]);
    }

    // for(int i_5=0;i_5<eigenvaluesdata.size();i_5++){
    //     alldata.push_back(eigenvaluesdata[i_5]);
    // }
    
    for(int i=0;i<alldata.size();i++){
        if(alldata.at(i)!=alldata.at(i)){
            alldata.at(i)=0;
        }
    }
    return alldata;
}

vector<float> CalculateFeatureVector::mergetovectororder(){
    float subdensitydata=subdensity();
    vector<float> degreecorrelationdata=degreecorrelation();
    vector<float> alldata;
    alldata.push_back(subdensitydata);
    for(int i_3=0;i_3<degreecorrelationdata.size();i_3++){
        alldata.push_back(degreecorrelationdata[i_3]);
    }
    return alldata;
}

void CalculateFeatureVector::print(){
    vector<float> alldata=mergetovector();
    for(vector<float>::iterator it=alldata.begin();it!=alldata.end();it++){
        cout<<*it<<" ";
    }
}
