/*************************************************************************
    > File Name: calculatetfidf.cpp
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Friday, June 17, 2016 18:12:52
 ************************************************************************/
#include "calculatetfidf.h"
#include "calculatefeaturevector.h"

Calculatetfidf::~Calculatetfidf(){

}
Calculatetfidf::Calculatetfidf(vector<vector<string> >* vclusters1,map<string,float>* mat_map1){
    vclusters=vclusters1;
    mat_map=mat_map1;
}

// Calculate tf-idf
vector<vector<float> > Calculatetfidf::updatefeaturevector(){
	vector<vector<float> > verctor14,tf,idf,tfidf;

	for(int i=0;i<vclusters->size();i++){
	    CalculateFeatureVector cfv1(&vclusters->at(i),mat_map);
	    vector<float> verctor14temp=cfv1.mergetovector();
            
	    verctor14.push_back(verctor14temp);
	    verctor14temp.clear();
	}
	    
	vector<float> rowsum,colsum;
	float sumtemp;
	for(int i=0;i<vclusters->size();i++){
	    sumtemp=0;
	    for(int j=0;j<14;j++){
	        sumtemp+=verctor14.at(i).at(j);
	    }   
	    rowsum.push_back(sumtemp);
	}  

	for(int i=0;i<14;i++){
	    sumtemp=0;
        for(int j=0;j<vclusters->size();j++){
	       sumtemp+=verctor14.at(j).at(i);
	    }   
	    colsum.push_back(sumtemp);
	}   

	for(int i=0;i<vclusters->size();i++){   
	    vector<float> tftemp;  
	    for(int j=0;j<14;j++){
	        if(rowsum.at(i)!=0){
	            tftemp.push_back(verctor14.at(i).at(j)/rowsum.at(i));
	        }else{
	        	tftemp.push_back(0);
	        }
	    }   
	    tf.push_back(tftemp);
	    tftemp.clear();
	}  

	for(int i=0;i<vclusters->size();i++){   
	    vector<float> idftemp;  
	    for(int j=0;j<14;j++){
	        idftemp.push_back(log((colsum.at(j)+1)/verctor14.at(i).at(j)));
	    }   
	    idf.push_back(idftemp);
	    idftemp.clear();
	} 		
        
	for (int i = 0; i < vclusters->size(); i++){
	    vector<float> tfidftemp; 
	    for(int j=0;j<14;j++){
            tfidftemp.push_back(tf.at(i).at(j)*idf.at(i).at(j));
	    }
	    tfidf.push_back(tfidftemp);
	    tfidftemp.clear();
	}

	return tfidf;
}

vector<float> Calculatetfidf::getfeaturevector(vector<string>* vcluster1){
    vector<float> tfidftemp;   
	for(int i=0;i<tfidf.size();i++){
	    if(vclusters->at(i)==*vcluster1){
	    	for(int j=0;j<tfidf.at(i).size();j++){
	    		tfidftemp.push_back(tfidf.at(i).at(j));
	    	}
            break;
	    }   	    	
	}
    return tfidftemp;
}