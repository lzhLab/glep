/*************************************************************************
    > File Name: seedcluster.cpp
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Thursday, June 16, 2016 22:15:16
 ************************************************************************/

#include<iostream>
#include "seedcluster.h"

using namespace std;
using namespace Eigen;

GetSeedCluster::GetSeedCluster(int rclen):rowcollen(rclen){

}

GetSeedCluster::~GetSeedCluster(){

}

// Establish the adjacency matrix for each node
MatrixXf GetSeedCluster::getMatrix(vector<string> *rowcolname,map<string,float> *mat_map){
    MatrixXf mat_w(rowcollen,rowcollen);
    mat_w=MatrixXf::Zero(rowcollen,rowcollen);
    for(int i=0;i<rowcollen;i++){
        for(int j=0;j<rowcollen;j++){
            string rcname_1='-'+rowcolname->at(i)+'-'+rowcolname->at(j);
            string rcname_2='-'+rowcolname->at(j)+'-'+rowcolname->at(i);
            map<string,float>::iterator itmatfind_1=mat_map->find(rcname_1);
            map<string,float>::iterator itmatfind_2=mat_map->find(rcname_2);         
            if(itmatfind_1!=mat_map->end()){
                mat_w(i,j)=itmatfind_1->second;
            }
            if(itmatfind_2!=mat_map->end()){
                mat_w(i,j)=itmatfind_2->second;
            }          
        }
    }

    //Normalize each line
    for(int i=0;i<rowcollen;i++){
        float rowsum=mat_w.row(i).sum();
        for(int j=0;j<rowcollen;j++){
            mat_w(i,j)=mat_w(i,j)/rowsum;
        }
    }
    return mat_w;
}

MatrixXf GetSeedCluster::getpi(MatrixXf* mat_w){
    MatrixXf mat_I=MatrixXf::Identity(rowcollen,rowcollen);
    MatrixXf mat_Start=MatrixXf::Identity(rowcollen,rowcollen);
    float c=0.15;
    MatrixXf pi=((mat_I-mat_w->transpose()*(1-c))).inverse()*mat_Start*c; 
    return pi;
}

// When the value is greater than the threshold, the nodes are added to the vcluster, and the two-dimensional matrix vclusters stores the calculated result
vector<vector<string> > GetSeedCluster::getseed(float gseedthreshold,MatrixXf pi,vector<string> rowcolname){
    vector<vector<string> > vclusters;
    vector<string> vcluster;
    for(int i=0;i<rowcollen;i++){
        for(int j=0;j<rowcollen;j++){
            if(pi(j,i)>gseedthreshold){
                vcluster.push_back(rowcolname[j]);
            }
        }
        vclusters.push_back(vcluster);
        vcluster.clear();
    }
    return vclusters;
}

//Remove classes with nodes less than 3
void GetSeedCluster::cleardata(vector<vector<string> >* vclusters){
    int sum=0;
     for(int i=vclusters->size()-1;i>=0;i--){
        if(vclusters->at(i).size()<3){     
           sum++;       
        }
    }  
    vclusters->resize(vclusters->size()-sum);
}

//Traversing the upper triangle, the matrix of operations is the initial division of the matrix
void GetSeedCluster::seeduniq(vector<vector<string> > *vclusters){
    vector<string> vtemp;
    
    cleardata(vclusters);

    for(int i=0;i<vclusters->size();i++){
        for(int j=i+1;j<vclusters->size();j++){
            set_intersection(vclusters->at(i).begin(),vclusters->at(i).end(),vclusters->at(j).begin(),vclusters->at(j).end(),back_inserter(vtemp));
            float sizevalue=((float)vtemp.size())/vclusters->at(j).size();
            if(sizevalue>=0.98){
                vclusters->erase(vclusters->begin()+j);
                j=j-1;
            }
            vtemp.clear();
        }
    }
}
