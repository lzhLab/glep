/*************************************************************************
    > File Name: expandcluster.cpp
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Saturday, June 18, 2016 23:49:57
 ************************************************************************/
#include "expandcluster.h"
#include "calculatetfidf.h"
Finalcluster::~Finalcluster(){

}
Finalcluster::Finalcluster(vector<vector<string> >* vclusters1,map<string,float>* mat_map1,vector<string>* rowcolname,int degree1,float similarity1){
    vclusters=vclusters1;
    mat_map=mat_map1;
    allnodes=rowcolname;
    degree=degree1;
    similarity=similarity1;
}

void Finalcluster::GlobalProcess(){    

	for(int i=0;i<vclusters->size();i++){
        for(int k=0;k<=degree;k++){
          Calculatetfidf cfv1(vclusters,mat_map);
          vector<string> tempnode=getAlllastNodesClusters(vclusters->at(i));

          for(int j=0;j<tempnode.size();j++){
              bool mark=true;
              for(int d=0;d<vclusters->at(i).size();d++){
                if(vclusters->at(i).at(d)==tempnode.at(j)){
                  mark=false;
                  break;
                }
              } 

              if(mark){
                vector<vector<float> > tfidf1=cfv1.updatefeaturevector();
                vclusters->at(i).push_back(tempnode.at(j));
                vector<vector<float> > tfidf2=cfv1.updatefeaturevector();

                float cosBandA=ComputeCos(tfidf1.at(i),tfidf2.at(i));  
                if(cosBandA<similarity){
                    vclusters->at(i).resize(vclusters->at(i).size()-1);
                }
              }
          }
        }
     }
 }

bool Finalcluster::check(vector<string> vcluster,string nodetemp){
    for(int i=0;i<vcluster.size();i++){
        string tempmap='-'+vcluster.at(i)+'-'+nodetemp;
        map<string,float>::iterator itmatfind_1=mat_map->find(tempmap);
        if(itmatfind_1!=mat_map->end()){
            return true;
        }
    }
    return false;
}

vector<string> Finalcluster::getAlllastNodesClusters(vector<string> vcluster){
    vector<string>  alllastnodescluster,onedegree;
    vector<string>::iterator it,it1;
    for(int i=0;i<vcluster.size();i++){
        set_difference(allnodes->begin(),allnodes->end(),vcluster.begin(),vcluster.end(),back_inserter(alllastnodescluster));
    }

    for(int j=0;j<alllastnodescluster.size();j++){
        if(check(vcluster,alllastnodescluster.at(j))){
            bool log=true;
            for(int k=0;k<onedegree.size();k++){
                if(onedegree.at(k)==alllastnodescluster.at(j)){
                  log=false;
                  break;
                }
            }
            if(log){
                onedegree.push_back(alllastnodescluster.at(j));
            }            
        }
    }

    return onedegree;
}

void Finalcluster::gofowared(vector<vector<string> >* vclusters,int index){
	for(int i=index;i<vclusters->size()-1;i++){
		int j=i+1;
		vclusters->at(i).erase(vclusters->at(i).begin(),vclusters->at(i).end());
		for(int k=vclusters->at(j).size()-1;k>=0;k--){
			vclusters->at(i).insert(vclusters->at(i).begin(),vclusters->at(j).at(k));
		}		
	}
	vclusters->resize(vclusters->size()-1);
}


float Finalcluster::ComputeCos(vector<float> A,vector<float> B){
    float cosresult;
    if((norm(A)*norm(B))==0){
    	cosresult=0;
    }else{
        cosresult=InnerProduct(A,B)/(norm(A)*norm(B));
    }
    if(cosresult==cosresult){
    	return cosresult;
    }else{
    	return 0;
    }
}

float Finalcluster::norm(vector<float> A){
    float res=0;
    for(int i=0;i<A.size();i++){
    	if(A[i]!=A[i]){
    		res+=0;
    	}else{
    		res+=pow(A[i],2);
    	}     
    }
    if(res!=0){
        return sqrt(res);
    }else{
        return 0;
    }
    
}

float Finalcluster::InnerProduct(vector<float> A,vector<float> B){
    float res=0;
    for(int i=0;i<A.size();i++){
    	if((A[i]!=A[i])||(B[i]!=B[i])){
           res+=0;
    	}else{
    	   res+=A[i]*B[i];
    	}
    }
    return res;
}