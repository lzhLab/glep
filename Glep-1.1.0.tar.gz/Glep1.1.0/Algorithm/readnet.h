/*************************************************************************
    > File Name: readnet.h
    > Author: Wu Shaogui
    > Mail: wshg_gxu@163.com
    > Created Time: Wednesday, June 15, 2016 11:30:15
 ************************************************************************/


#ifndef _READNET_H
#define _READNET_H
#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include <cstring>
#include <algorithm>
using namespace std;
class ReadNet{
    private:
        char* filein;
    public:
        ReadNet(char*);
        ~ReadNet();
    void readOriginGraph(vector<string> *rowcolname,map<string,float> *mat_map);
};
#endif
