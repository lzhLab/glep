# calculate single residue propensity values and residue pair propensity values
from scipy import array,zeros
from numpy import arange
from math import log10,fabs,log
from sys import argv
import networkx as nx 
from subprocess import Popen,PIPE
from os import path
from Bio.PDB import PDBParser
import ConfigParser

Tri2Mono = {'ALA':'A', 'ARG':'R', 'ASN':'N', 'ASP':'D', 'CYS':'C', 'GLU':'E', 'GLN':'Q', 'GLY':'G', 'HIS':'H', 'ILE':'I', 'LEU':'L', 'LYS':'K', 'MET':'M', 'PHE':'F', 'PRO':'P', 'SER':'S', 'THR':'T', 'TRP':'W', 'TYR':'Y', 'VAL':'V'}
Tri2Itg = {'ALA':13, 'ARG':0, 'ASN':2, 'ASP':3, 'CYS':15, 'GLU':5, 'GLN':4, 'GLY':12, 'HIS':6, 'ILE':19, 'LEU':17, 'LYS':1, 'MET':14, 'PHE':16, 'PRO':7, 'SER':10, 'THR':11, 'TRP':9, 'TYR':8, 'VAL':18}
Mono2Itg = {'A':13, 'R':0, 'N':2, 'D':3, 'C':15, 'E':5, 'Q':4, 'G':12, 'H':6, 'I':19, 'L':17, 'K':1, 'M':14, 'F':16, 'P':7, 'S':10, 'T':11, 'W':9, 'Y':8, 'V':18}
Itg2Mono = {0:'R', 1:'K', 2:'N', 3:'D', 4:'Q', 5:'E', 6:'H', 7:'P', 8:'Y', 9:'W', 10:'S', 11:'T', 12:'G', 13:'A', 14:'M', 15:'C', 16:'F', 17:'L', 18:'V', 19:'I'}

nAA = 20
FSZ = 1770
FSELECT = 144	#257

# load epitope id
def LoadEtpId(szPath) :
	lEtpId = []
	fIn = open(szPath)
	for line in fIn :
		lEtpId.append(line.split()[0])
	fIn.close()
	return lEtpId

# load surface residue contacting graph
def LoadSurfaceGraph(szPath) :
	dOrthoList = {}
	fIn = open(szPath)
	for line in fIn :
		pstns = line.split()
		dOrthoList[pstns[0]] = pstns[1:]
	fIn.close()
	return dOrthoList

# load position and its residue name
def LoadPositionResidue(szPath) :
	dPstnRsd = {}
	fIn = open(szPath)
	for line in fIn :
		pstnrsd = line.split()
		if pstnrsd[0] not in dPstnRsd:
			rsd = Tri2Mono.get(pstnrsd[1], 'X')
			if rsd != 'X' :
				dPstnRsd[pstnrsd[0]] = rsd
			else :
				print('abnormal residue:', szPath, line)
	fIn.close()
	return dPstnRsd

def LoadFSelect(szPath) :
	lFSelect = []
	fh = open(szPath)
	for line in fh :
		lFSelect.append(eval(line.split()[0]))
	fh.close()
	return lFSelect

def ImportFIndex(fPath) :
	fh = open(fPath)
	dFIdx = {}
	for line in fh :
		line = line.split()
		dFIdx[line[0]] = eval(line[1])
	fh.close()
	return dFIdx
	
def LoadArray(szIPath, nRow, nCol) :
	if nRow == 1 :
		arr = zeros(nCol, float)
		fIn = open(szIPath)
		vals = fIn.readline().split()
		for i in range(nCol) :
			arr[i] = eval(vals[i])
		fIn.close()
	else :
		arr = zeros((nRow,nCol), float)
		fIn = open(szIPath)
		for i in range(nRow) :
			vals = fIn.readline().split()
			for j in range(nCol) :
				arr[i][j] = eval(vals[j])
		fIn.close()
	return arr

def LCmbArray(a1,a2,alpha) :
	if a1.shape != a2.shape :
		print('mismatch dimension')
		return
	nShape = a1.shape
	a = zeros(nShape,float)
	for i in range(nShape[0]) :
		if len(nShape) == 2 :
			for j in range(nShape[1]) :
				a[i][j] = a1[i][j]*alpha + a2[i][j]*(1-alpha)
		else :
			a[i] = a1[i]*alpha + a2[i]*(1-alpha)
	return a

def ContrastWeight(val, theta, gamma) :
	dVal = fabs(val)
	if dVal < 1 and dVal > 0:
		dVal = 1/(1+pow(theta*dVal/(1-dVal),-gamma))
	if val > 0 :
		return dVal
	else :
		return -dVal

def ContrastArray(arr, theta, gamma) :
	nShape = arr.shape
	if len(nShape) == 1 :
		for i in range(nShape[0]) :
			arr[i] = ContrastWeight(arr[i], theta, gamma)
	elif len(nShape) == 2 :
		for i in range(nShape[0]) :
			for j in range(nShape[1]) :
				arr[i][j] = ContrastWeight(arr[i][j], theta, gamma)
	else :
		print('dimension not supported')
	return arr

def MaskWeight(aTgt, aMsk1, aMsk2, mskThrd, amp,bMsk2) :
	aShape = aTgt.shape
	for i in range(aShape[0]) :
		for j in range(i,aShape[1]) :
			if bMsk2 > 0.5:
				if (aMsk1[i][j] >= mskThrd) and (aMsk2[i][j] >= mskThrd) :
					aTgt[i][j] = aTgt[i][j] * amp
					aTgt[j][i] = aTgt[i][j]
			else :
				if (aMsk1[i][j] >= mskThrd) :
					aTgt[i][j] = aTgt[i][j] * amp
					aTgt[j][i] = aTgt[i][j]
	return aTgt
#--------------------------------------------------part 2: generate MCL input file------------------------------------#
# generate MCL input file 
#	idChain: input surface graph id; 
#	aPrf: preference array
#	aSim: similarity array
#	szOPath: output path of labeled graph

def MclFormat(idChain, amcl, szOPath) :
	aPrf = amcl[0]
	aSim = amcl[1]
	szPath = 'mediaData/graph/gSruf/%s' %idChain
	dOrthoList = LoadSurfaceGraph(szPath)
	szPath = 'mediaData/graph/atomIdx/%s' %idChain
	dPstnRsd = LoadPositionResidue(szPath)

	nPoint = len(dOrthoList)
	lPoint = sorted(dOrthoList.keys())
	aAP = zeros((nPoint,nPoint),float)+1 
	apIdxI = apIdxJ = 0
	for start in lPoint :
		startRsd = dPstnRsd.get(start, 'X')
		if startRsd != 'X' :
			startIdx = Mono2Itg[startRsd]
			apIdxI = lPoint.index(start)
			aAP[apIdxI][apIdxI] = aPrf[startIdx]-1
			for end in dOrthoList[start] :
				endRsd = dPstnRsd.get(end, 'X')
				if endRsd != 'X' :
					endIdx = Mono2Itg[endRsd]
					apIdxJ = lPoint.index(end)
					aAP[apIdxI][apIdxJ] = aSim[startIdx][endIdx]-1
	fOut = open(szOPath, 'w')
	
	#spare format
	for i in range(nPoint) :
		for j in range(i,nPoint) :
			if aAP[i][j] < 1 :
				fOut.write('%d %d %.3f\n' %(i+1,j+1,aAP[i][j]))
	fOut.close()

def MCLIn(amcl,idPath) :
	lEtpId = LoadEtpId(idPath)
	for idChain in lEtpId :
		szOPath = 'mediaData/MclIO/chi2/%s' %(idChain)
		MclFormat(idChain, amcl, szOPath)

#-------------------------------------------------part 3: cluster by MCL-------------------------------------------#
# tansform MCL output indices into positions
# lPosition: list of surface residue positions, index is the output of MCL-1
# lEtp: list of epitope position
def MclIdx2Pstn(lPosition, szIPath, szOPath) :
	fIn = open(szIPath)
	fOut = open(szOPath,'w')
	for line in fIn :
		lTmpPstn = []
		indices = line.split()
		for index in indices :
			index = eval(index)-1
			position = lPosition[index]
			lTmpPstn.append(position)
		fOut.write(' '.join(lTmpPstn))
		fOut.write('\n')
	fOut.close()
	fIn.close()

# cluster output file by MCL
def MCL(idChain, mclI) :

	cp = ConfigParser.SafeConfigParser()
	cp.read('globalsettings.conf')	
	gleppath=cp.get('commands','Glep')

	szPara = gleppath+' -d 2 -e 0.998 mediaData/MclIO/chi2/%s  mediaData/MclIO/chi2Out/%s' %(idChain,idChain) 
	Popen(szPara,shell=True).wait()

	szPath = 'mediaData/graph/gSruf/%s' %idChain
	dOrthoList = LoadSurfaceGraph(szPath)
	lPosition = sorted(dOrthoList.keys())
	szIPath = 'mediaData/MclIO/chi2Out/%s' %(idChain)
	szOPath = 'tmp.mcl'
	MclIdx2Pstn(lPosition, szIPath, szOPath)
	szPara = 'mv %s %s' %(szOPath,szIPath)
	Popen(szPara, shell=True).wait()
		
def MCLPredict(amcl,mclI,idPath) :
	MCLIn(amcl,idPath)
	lEtpId = LoadEtpId(idPath)
	for idChain in lEtpId :
		MCL(idChain,mclI)

#-------------------------------------------------part 4: predict and evaluate--------------------------------------#
# change the clusters generated by MCL to SVM input, and use SVM to predict epitope and non-epitope
# features are single residue and residue pairs which form the 230 dimension vector: 210 pair + 20 single

# get all the triangles in this cluster
def GetTriangle(cluster, dOrthoList) :
	lTriangle = []
	nNode = len(cluster)
	if nNode >= 3 :
		for i in range(nNode-2) :
			pstnI = cluster[i]
			neighborI = dOrthoList[pstnI]
			for j in range(i+1,nNode-1) :
				pstnJ = cluster[j]
				if not pstnJ in neighborI :
					continue
				neighborJ = dOrthoList[pstnJ]
				for k in range(j+1, nNode) :
					pstnK = cluster[k]
					if not ((pstnK in neighborI) and (pstnK in neighborJ)) :
						continue
					lTriangle.append([pstnI,pstnJ,pstnK])
	return lTriangle

# get all the pair of edges in each cluster
def GetPair(cluster,dOrthoList) :
	nNode = len(cluster)
	lPair = []
	if nNode >= 2 :
		for i in range(nNode-1) :
			pstnI = cluster[i]
			neighborI = dOrthoList[pstnI]
			for j in range(i+1,nNode) :
				pstnJ = cluster[j]
				if pstnJ in neighborI :
					lPair.append([pstnI,pstnJ])
	return lPair

# get each triangle value and its one dimension index 
def GetTriVal(pstnTri, a2, dPstnRsd, dFIdx) :
	rsdTri = [dPstnRsd[pstnTri[0]],dPstnRsd[pstnTri[1]],dPstnRsd[pstnTri[2]]]
	idxTri = list(sorted([Mono2Itg.get(rsdTri[0],19),Mono2Itg.get(rsdTri[2],19),Mono2Itg.get(rsdTri[2],19)]))
	idx1 = dFIdx[''.join([Itg2Mono[idxTri[0]],Itg2Mono[idxTri[1]],Itg2Mono[idxTri[2]]])]
	val = a2[idxTri[0]][idxTri[1]] + a2[idxTri[0]][idxTri[2]] + a2[idxTri[1]][idxTri[2]]
	return [idx1,val]
	
def GetPairVal(pstnPair, a2, dPstnRsd, dFIdx) :
	rsdPair = [dPstnRsd[pstnPair[0]],dPstnRsd[pstnPair[1]]]
	idxPair = list(sorted([Mono2Itg.get(rsdPair[0],19),Mono2Itg.get(rsdPair[1],19)]))
	idx1 = dFIdx[''.join([Itg2Mono[idxPair[0]],Itg2Mono[idxPair[1]]])]
	val = a2[idxPair[0]][idxPair[1]]
	return [idx1,val]

def GetSingleVal(pstn, a1, dPstnRsd, dFIdx) :
	rsd = dPstnRsd[pstn]
	idx = Mono2Itg.get(rsd,19)
	idx1 = dFIdx[Itg2Mono[idx]]
	val = a1[idx]
	return [idx1,val]

def FSelectSvmFormatTest(asvm,idchain,fOut,dFIdx,lFSel) :
	a1 = asvm[0]
	a2 = asvm[1]
	szPath = 'mediaData/graph/atomIdx/%s' %idchain	# position residue map
	dPstnRsd = LoadPositionResidue(szPath)
	szPath = 'mediaData/graph/gSruf/%s' %idchain		# surface graph
	dOrthoList = LoadSurfaceGraph(szPath)
	szPath = 'mediaData/MclIO/chi2Out/%s' %(idchain)
	fCluster = open(szPath)
	for cluster in fCluster :	# each file contains many clusters, and each cluster has several residue positions
		vCluster = zeros(FSELECT,float)	# each cluster maps to a 1770 dimensions vector
		nEdges = 0	# for normalize
		nNodes = 0
		cluster = cluster.split()	#[2:]
		lPair = GetPair(cluster,dOrthoList)
		lTriangle = GetTriangle(cluster, dOrthoList)
		nTriangle = len(lTriangle)
		nPair = len(lPair)
		nSingle = len(cluster)
		for pstnTri in lTriangle :
			valIdx = GetTriVal(pstnTri, a2, dPstnRsd, dFIdx)
			fsel = valIdx[0]+1
			if fsel in lFSel :
				vCluster[lFSel.index(fsel)] += (valIdx[1]/nTriangle)
			#vCluster[valIdx[0]] += (valIdx[1]/nTriangle)	# if multiple triangle is encountered, then sum them over
		for pair in lPair :
			valIdx = GetPairVal(pair, a2, dPstnRsd, dFIdx)
			fsel = valIdx[0]+1
			if fsel in lFSel :
				vCluster[lFSel.index(fsel)] += (valIdx[1]/nPair)
			#vCluster[valIdx[0]] += (valIdx[1]/nPair)
		for pstn in cluster :
			valIdx = GetSingleVal(pstn, a1, dPstnRsd, dFIdx)
			fsel = valIdx[0]+1
			if fsel in lFSel :
				vCluster[lFSel.index(fsel)] += (valIdx[1]/nSingle)
			#vCluster[valIdx[0]] += (valIdx[1]/nSingle)
		# normailize vector based on cluster size
		fOut.write('1 ')
		for i in range(FSELECT) :
			if vCluster[i] != 0 :
				fOut.write('%d:%.3f ' %(i+1,vCluster[i]))
		fOut.write('\n')
		del vCluster
	fCluster.close()

#---------------------------------------------Model training---------------------------------------#
def ImportModel(mdlPath) :
	lModel = []
	fIn = open(mdlPath)
	for model in fIn :
		lModel.append(model.split())
	fIn.close()
	return lModel

#-----------------------------------prediction and performance evaluation----------------------------#
# lPrd: vector of prediction, i.e. ['1','0','1',...]
# lWgt: performance of each classifier, i.e. [82.0, 70,...]	# float type
def Vote(lPrd, lWgt, thrd,probMode,probThrd):
	nSz = len(lPrd)
	bEven = False
	if probMode :
		nPositive = 0
		nNegative = 0
		for prob in lPrd :
			if eval(prob[1]) >= probThrd :
				nNegative += 1
			if eval(prob[2]) >= probThrd :
				nPositive += 1
		if nPositive > nNegative :
			return 1
		elif nPositive < nNegative :
			return 0
		else :
			bEven = True
	if (not probMode) or (bEven) :
		lPrdLbl = []
		for i in range(nSz) :
			lPrdLbl.append(eval(lPrd[i][0]))
		aPrd = array(lPrdLbl)
		if lWgt == [] :	# vote by count
			if aPrd.sum() >= (nSz/2.0) :
				return 1
			else :
				return 0
		else :	# vote by weight
			aWgt = array(lWgt)
			aWgt = aWgt / (aWgt.sum())
			aPrd = aPrd*aWgt
			if aPrd.sum() >= thrd :
				return 1
			else :
				return 0
			
def GetMCLWeight(mTheta,mGamma,mskThrd,bMsk2,mskRThrd,alpha) :
	a1 = LoadArray('mediaData/chi21_norm', 1, nAA)
	a1 = ContrastArray(a1, mTheta, mGamma)	# best parameter for chi2: 4, 2.3
	ar1 = LoadArray('mediaData/ratio1_norm',1,nAA)
	ar1 = ContrastArray(ar1,1,1)
	acr1 = LCmbArray(a1,ar1,alpha)

	a2 = LoadArray('mediaData/chi22_norm', nAA, nAA)
	aMsk1 = LoadArray('mediaData/chi22_norm_ebnd', nAA, nAA)
	aMsk2 = LoadArray('mediaData/chi22_norm_nebnd', nAA, nAA)
	a2 = MaskWeight(a2, aMsk1, aMsk2, mskThrd, 0, bMsk2)
	a2 = ContrastArray(a2, mTheta, mGamma)

	ar2 = LoadArray('mediaData/ratio2_norm',nAA,nAA)
	aMskr1 = LoadArray('mediaData/ratio2_norm_ebnd',nAA,nAA)
	aMskr2 = LoadArray('mediaData/ratio2_norm_ebnd',nAA,nAA)
	ar2 = MaskWeight(ar2,aMskr1,aMskr2,mskRThrd,0,bMsk2)
	ar2 = ContrastArray(ar2,1,1)
	acr2 = LCmbArray(a2,ar2,alpha)
	return [acr1,acr2]

def GetSVMWeight(sTheta,sGamma,mskThrd,bMsk2,mskRThrd,alpha) :
	a1 = LoadArray('mediaData/chi21_norm_sign', 1, nAA)
	a1 = ContrastArray(a1, sTheta, sGamma)
	ar1 = LoadArray('mediaData/ratio1_norm_sign',1,nAA)
	ar1 = ContrastArray(ar1,1,1)
	acr1 = LCmbArray(a1,ar1,alpha)

	a2 = LoadArray('mediaData/chi22_norm_sign', nAA, nAA)
	aMsk1 = LoadArray('mediaData/chi22_norm_ebnd', nAA, nAA)
	aMsk2 = LoadArray('mediaData/chi22_norm_nebnd', nAA, nAA)
	a2 = MaskWeight(a2, aMsk1, aMsk2, mskThrd, 0, bMsk2)
	a2 = ContrastArray(a2, sTheta, sGamma)

	ar2 = LoadArray('mediaData/ratio2_norm_sign',nAA,nAA)
	aMskr1 = LoadArray('mediaData/ratio2_norm_ebnd',nAA,nAA)
	aMskr2 = LoadArray('mediaData/ratio2_norm_ebnd',nAA,nAA)
	ar2 = MaskWeight(ar2,aMskr1,aMskr2,mskRThrd,0,bMsk2)
	ar2 = ContrastArray(ar2,1,1)

	acr2 = LCmbArray(a2,ar2,alpha)
	return [acr1, acr2]

def Predict(amcl,asvm,idchain,lMdlPath,dFIdx,lFSel,mclI,thrd,probMode,probThrd) :
	PLBL = 1	# positive lable of svm
	

	# form MCL input
	mclIPath = 'mediaData/MclIO/chi2/%s' %(idchain)
	MclFormat(idchain, amcl, mclIPath)

	# cluster by MCL
	MCL(idchain, mclI)

	svmOPath = 'mediaData/svmIO/chi2/%s.svm' %(idchain)
	fOut = open(svmOPath, 'w')
	FSelectSvmFormatTest(asvm,idchain,fOut,dFIdx,lFSel)
	fOut.close()
	# predict by SVM
	# test line by line
	# multiple classifier prediction
	lSvmPred = []	#[[1, 1, 0, 0, 1, 1,... (for the first cluster, number of value is equal to number of classifiers)],[(for the second cluster)]]
	lWgt = []
	for modelPath in lMdlPath :
		lWgt.append(eval(modelPath[1]))	# f-score of cross validation
	fSvm = open(svmOPath)

	cp = ConfigParser.SafeConfigParser()
	cp.read('globalsettings.conf')	
	svmpredict=cp.get('commands','svm-predict')

	print "here-2"
	print svmpredict
	
	for line in fSvm :
		svmpred = []
		testPath = 'mediaData/svmIO/chi2/%s.svm'%(idchain)
		fTest = open(testPath,'w')
		fTest.write(line)
		fTest.close()
		for modelPath in lMdlPath :
			modelPath = modelPath[0]
			outPath = 'mediaData/svmIO/chi2/%s.svmo'%(idchain)
			#szPara = '/home/lzhao/Local/libsvm-3.1/svm-predict %s %s %s' %(testPath,modelPath,outPath)
			szPara = svmpredict+' -b 1 %s %s %s' %(testPath,modelPath,outPath)
			Popen(szPara,shell=True).wait()
			
			# get prediction performance
			# load svm prediction
			fTmp = open(outPath)
			# skip label information
			labels = fTmp.readline().split()[1:]
			prob = fTmp.readline().split()
			print(prob)
			if labels[0] == '1' :	# exchange probability if label with "1 0", otherwise no change
				tmpprob = prob[2]
				prob[1] = prob[2]
				prob[2] = tmpprob
			svmpred.append(prob)
			#svmpred.append(fTmp.readline().split()[0])	# only have one line
			fTmp.close()
		lSvmPred.append(svmpred)
	fSvm.close()
	# vote by prediction results of multiple classifiers
	#probMode = 0
	#probThrd = 0.7
	lVote = []
	for svmprd in lSvmPred :
		lVote.append(Vote(svmprd, lWgt, thrd,probMode,probThrd))
	# load mcl prediction
	print(lVote)
	lMclCluster = []
	mclOPath = 'mediaData/MclIO/chi2Out/%s' %(idchain)
	fTmp = open(mclOPath)
	for line in fTmp :
		lMclCluster.append(line.split())	#[2:])
	fTmp.close()
	# get prediction
	lPrd = []
	for i in range(len(lVote)) :
		if lVote[i] == PLBL :
			lPrd.append(lMclCluster[i])
	return lPrd

# merge clusters based on their spatial connectivity, using connected component to merge
def MergeCluster(lCluster, idChain) :
	szPath = 'mediaData/graph/gSruf/%s' %idChain		# surface graph
	dOrthoList = LoadSurfaceGraph(szPath)
	nCluster = len(lCluster)
	
	G = nx.Graph()
	for i in range(nCluster) :
		G.add_node(i)
	for i in range(nCluster) :
		lPstnI = lCluster[i]
		for pstnI in lPstnI :
			lNeighborI = dOrthoList[pstnI]
			for j in range(i+1,nCluster) :
				lPstnJ = lCluster[j]
				for pstnJ in lPstnJ :
					if pstnJ in lNeighborI :
						G.add_edge(i,j)
	lCC = nx.connected_components(G)
	lMCluster = []
	for cc in lCC :
		mcluster = []
		for index in cc :
			mcluster.extend(lCluster[index])
		lMCluster.append(mcluster)
	return lMCluster
	
# get specified PDB chain amino acid sequence
def GetChain(pdbPath, chainId) :
	aa = []
	structure = PDBParser().get_structure('tmp', pdbPath)
	for model in structure.get_list() :
		for chain in model.get_list() :
			chainid = chain.get_id()
			if chainid != chainId :
				continue
			for residue in chain.get_list() :
				if residue.get_id()[0] == ' ' :
					monoAA = Tri2Mono.get(residue.get_resname(), 'X')
					if monoAA != 'X' :
						aa.append(monoAA)
					else :
						aa.append('A')
			return aa
	return aa
	
# run prediction
def RunPrd(amcl,asvm,idchain,lMdlPath,dTriIdx,lFSel,mclI,thrd,bSurface,probMode,probThrd) :
	pdbPath = 'mediaData/chains/%s.pdb' %idchain
	if not path.exists(pdbPath) :
		print('%s does not exist' %idchain)
		return
	lPrd = Predict(amcl,asvm,idchain,lMdlPath,dTriIdx,lFSel,mclI,thrd,probMode,probThrd)
	print(lPrd)
	# lPrd = MergeCluster(lPrd, idchain)
	return lPrd
	
def Run(idchain) :
	mskThrd = 0.14
	mclI = 1.8
	voteThrd = 0.3
	bMsk2 = 0
	mTheta = 3
	mGamma = 3
	sTheta = 3.5
	sGamma = 3
	alpha = 0.3
	mskRThrd = 0.25
	bSurface = 1
	probMode = 1
	probThrd = 0.55
	dTriIdx = ImportFIndex('mediaData/fIndex')
	lFSel = LoadFSelect('mediaData/fSelect')
	asvm = GetSVMWeight(sTheta,sGamma,mskThrd,bMsk2,mskRThrd,alpha)
	amcl = GetMCLWeight(mTheta,mGamma,mskThrd,bMsk2,mskRThrd,alpha)
	lMdlPath = ImportModel('mediaData/modelPath')
	
	lPrd = RunPrd(amcl,asvm,idchain,lMdlPath,dTriIdx,lFSel,mclI,voteThrd,bSurface,probMode,probThrd)

	return lPrd
	
if __name__ == '__main__' :
	Run('B')
