from sys import argv
from operator import itemgetter
from subprocess import Popen
import ConfigParser
from BldSurfGraphWeb import Run as RunBldGraph
from BePreWeb import Run as RunBePre

Tri2Mono = {'ALA':'A', 'ARG':'R', 'ASN':'N', 'ASP':'D', 'CYS':'C', 'GLU':'E', 'GLN':'Q', 'GLY':'G', 'HIS':'H', 'ILE':'I', 'LEU':'L', 'LYS':'K', 'MET':'M', 'PHE':'F', 'PRO':'P', 'SER':'S', 'THR':'T', 'TRP':'W', 'TYR':'Y', 'VAL':'V'}

def DownloadPdb(pdbId) :
	# szPara = "curl -o 'downloads/tmpPdb' 'http://www.rcsb.org/pdb/download/downloadFile.do?fileFormat=pdb&compression=NO&structureId='"+pdbId
	szPara = "wget 'https://files.rcsb.org/view/%s.pdb' -O downloads/tmpPdb"%pdbId
	Popen(szPara,shell=True).wait()
	#SimplifyPdb('downloads/tmpPdb')
	
def SimplifyPdb(pdbPath,szDir) :
	#szPara = "cat %s | egrep '^ATOM |^TER ' > %s/pdb; mv %s/pdb %s" %(pdbPath,szDir,szDir,pdbPath)
	szPara = "cat %s | egrep '^ATOM |^TER ' > %s/pdb" %(pdbPath,szDir)

	#szPara = "cat %s | egrep '^ATOM |^TER ' > %s/tmp" %(pdbPath,szDir)
	Popen(szPara,shell=True).wait()
	
def SeparateChain(pdbPath, chains) :
	fhi = open(pdbPath)
	fho = None
	lchain = []
	prechain = ''
	for line in fhi :
		curchain = line[21]
		if chains == '-' :	# not specified
			if curchain != prechain :
				if prechain == '' :
					fho = open('mediaData/chains/%s.pdb' %curchain,'w')
					fho.write(line)
				else :
					fho.close()
					fho = open('mediaData/chains/%s.pdb' %curchain,'w')
					fho.write(line)
				prechain = curchain
				lchain.append(curchain)
			else :
				fho.write(line)
		elif curchain in chains :
			if curchain != prechain :
				if prechain == '' :
					fho = open('mediaData/chains/%s.pdb' %curchain,'w')
					fho.write(line)
				else :
					fho.close()
					fho = open('mediaData/chains/%s.pdb' %curchain,'w')
					fho.write(line)
				prechain = curchain
				lchain.append(curchain)
			else :
				fho.write(line)
	if fho :
		fho.close()
	fhi.close()
	return lchain

def GetChain(pdbPath, chainId) :
	chain = ''
	fh = open(pdbPath)
	prePstn = ''
	for line in fh :
		if line[21] == chainId :
			if line[:4] == 'ATOM' :
				curPstn = line[22:27]
				if curPstn != prePstn :
					chain += Tri2Mono.get(line[17:20],'V')
					prePstn = curPstn
	fh.close()
	return chain

def CheckChainType(pdbPath, chainId) :
	chain = GetChain(pdbPath, chainId)
	# sequence numbering by AbNum
	#szPara = "java -jar AbSequenceNmb.jar 1 %s -a mediaData/%s.aa" %(chain,chainId)

	cp = ConfigParser.SafeConfigParser()
	cp.read('globalsettings.conf')	
	ANARCI=cp.get('commands','ANARCI')

	# szPara = "wget -O mediaData/chains/%s.aa 'http://www.bioinf.org.uk/cgi-bin/abnum/abnum.pl?plain=1&aaseq=%s&scheme=-a'" %(chainId,chain)
	szPara = ANARCI+" -i %s --scheme martin | tail -n +8 > mediaData/chains/%s.aa"%(chain,chainId)
	Popen(szPara,shell=True).wait()
	fh = open('mediaData/chains/%s.aa' %chainId)
	chainType = fh.readline().split()
	fh.close()
	if chainType == [] :
		return 'G'
	else :
		return chainType[0][0]
	
def GetChainType(lchain) :
	dChainType = {}
	for chainId in lchain :
		chainType = CheckChainType('mediaData/chains/%s.pdb' %chainId, chainId)
		
		if chainType in dChainType:
			dChainType[chainType].append(chainId)
		else :
			dChainType[chainType] = [chainId]
	return dChainType
	
def ExportAbChain(dChainType) :
	fh = open('hlChain','w')
	for key in dChainType.keys() :
		if key != 'G' :
			fh.write('%s ' %key)
			fh.write(' '.join(dChainType[key]))
			fh.write('\n')
	fh.close()
	
def PrepareData(choice, pdbId, chains) :
	#chains = chains.strip()
	#choice = argv[1]	# 1: upload data, 2: download data
	if choice == '1' :
		pdbPath = 'uploads/tmpPdb'

		szPara = "cp %s %s"%(pdbId,pdbPath)
		Popen(szPara,shell=True).wait()

		#szPara = 'cp uploads/tmp uploads/tmpPdb'	#; rm -f %s; mv uploads/tmp %s' %(pdbPath,pdbPath,pdbPath)
		#szPara = 'cp %s uploads/tmp' %(pdbPath)
		#Popen(szPara,shell=True).wait()
		SimplifyPdb(pdbPath,'uploads')

		pdbPath = 'uploads/pdb'
		lchain = SeparateChain(pdbPath,'-')
		lchain.insert(0,pdbId)
		return lchain
	elif choice == '2' :
		DownloadPdb(pdbId)
		pdbPath = 'downloads/tmpPdb'
		SimplifyPdb(pdbPath,'downloads')
		pdbPath = 'downloads/pdb'
		lchain = SeparateChain(pdbPath,chains)
		if chains != '-' :
			lchain = [pdbId]
			for chain in chains :
				lchain.append(chain)
		else :
			lchain.insert(0,pdbId)
		return lchain
	else :
		print('wrong choice')
		
			
def Naccess(szPath) :

	cp = ConfigParser.SafeConfigParser()
	cp.read('globalsettings.conf')	
	naccesspath=cp.get('commands','naccess')
	
	szPara = naccesspath+' '+szPath

	Popen(szPara, shell=True).wait()
	Popen('mv *.asa *.rsa *.log mediaData/naccessOut/', shell=True).wait()
	
def RunPredict(chain) :
	chainPath = 'mediaData/chains/%s.pdb' %chain
	Naccess(chainPath)

	RunBldGraph(chain,10,10)

	lPrd = RunBePre(chain)
	return lPrd

def SortPstn(lPstn) :
	lPstnEx = []
	for pstn in lPstn :
		if pstn[-1].isalpha() :
			pstnEx = [eval(pstn[:-1]),pstn[-1]]
		else :
			pstnEx = [eval(pstn),'']
		lPstnEx.append(pstnEx)
	lPstnEx = sorted(lPstnEx, key=itemgetter(0))
	lSortPstn = []
	for pstnEx in lPstnEx :
		pstn = '%d%s' %(pstnEx[0],pstnEx[1])
		lSortPstn.append(pstn)
	return lSortPstn
	
def Predict(choice, pdbId, chains) :
	lchain = PrepareData(choice, pdbId, chains)
	dChainType = GetChainType(lchain[1:])
	ExportAbChain(dChainType)
	gChain = dChainType['G'][:]
	gChain.insert(0,lchain[0])
	lchain = gChain
	pdbId = lchain[0]
	fOut = open('prdEtp','w')
	fdl = open('Glep','w')	# for customer to download
	fdl.write('PDB ID: %s\n' %pdbId)
	for chain in lchain[1:] :
		prd = RunPredict(chain)
		if prd != [] :
			fdl.write('Chain: %s; Number of predicted epitopes: %d\n' %(chain,len(prd)))
			fOut.write('%s %d\n' %(chain,len(prd)))
			i = 1
			for etp in prd :
				etp = SortPstn(etp)
				fOut.write(' '.join(etp))
				fOut.write('\n')
				fdl.write('Epitope %s-%d: ' %(chain,i))
				fdl.write(' '.join(etp))
				fdl.write('\n')
				i += 1
		else :
			fOut.write('%s 0\n' %chain)
			fdl.write('Chain: %s; Number of predicted epitopes: 0\n' %chain)
	fOut.close()
	fdl.close()

def Initsetting():
	commands=['naccess','qdelaunay','svm-predict','ANARCI','Glep']
	cp = ConfigParser.SafeConfigParser()
	cp.read('globalsettings.conf')

	if not cp.has_section('commands'):
		cp.add_section('commands')
		cp.write(open('globalsettings.conf', 'w'))

	for command in commands:
		if not cp.has_option('commands',command):
			cp.set('commands',command,'')
			cp.write(open('globalsettings.conf', 'w'))
		commandpathtmp=cp.get('commands',command)
		if commandpathtmp=="":
			print("The path of '"+command+"' is not configured, please set in globalsettings.conf")
			if command=="Glep":
				print("Glep is compiled in the 'Algorithm' directory.")
			exit()

if __name__ == '__main__' :
	Initsetting()

	if len(argv)==2:
		antigene='-'
	else:
		antigene=argv[2]
	Predict('2', argv[1], antigene)

